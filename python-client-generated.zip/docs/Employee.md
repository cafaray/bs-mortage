# Employee

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **str** | Beschreibung des | [optional] 
**type** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**created** | **int** |  | [optional] 
**modified** | **int** |  | [optional] 
**birth_date** | **str** |  | [optional] 
**city** | **str** |  | [optional] 
**department** | **str** |  | [optional] 
**email** | **str** |  | [optional] 
**gender** | **str** |  | [optional] 
**is_active** | **bool** |  | [optional] 
**metadata** | [**EmployeesArrayInnerMetadata**](EmployeesArrayInnerMetadata.md) |  | [optional] 
**phone** | **str** |  | [optional] 
**postal** | **int** |  | [optional] 
**state** | **str** |  | [optional] 
**street** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


